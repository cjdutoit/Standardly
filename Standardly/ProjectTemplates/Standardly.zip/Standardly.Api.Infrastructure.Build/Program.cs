namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
