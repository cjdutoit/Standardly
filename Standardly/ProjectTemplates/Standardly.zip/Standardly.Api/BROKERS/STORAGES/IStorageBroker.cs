﻿namespace $safeprojectname$.Brokers.Storages
{
    public partial interface IStorageBroker
    {
    }
}
