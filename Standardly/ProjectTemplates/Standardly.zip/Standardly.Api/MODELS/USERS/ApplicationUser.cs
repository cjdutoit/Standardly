using Microsoft.AspNetCore.Identity;
using System;

namespace $safeprojectname$.Models.Users
{
    public class ApplicationUser : IdentityUser<Guid>
    {
    }
}
